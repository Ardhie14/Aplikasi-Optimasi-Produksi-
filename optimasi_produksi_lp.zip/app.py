# Aplikasi Streamlit untuk Optimasi Produksi

import streamlit as st
# ...